 <?php  
 $connect = mysqli_connect("localhost", "root", "", "testing");  

if($_GET){
    $output = '';  
    $message = ''; 
    $id = $_GET["employee_id"];
    
    
    $query = "DELETE FROM tbl_employee WHERE id = '$id'";
    
    $result = mysqli_query($connect,$query);
    if($result){
    $message = "DELETED";
    
      $output .= '<label class="text-danger">' . $message . '</label>';  
           $select_query = "SELECT * FROM tbl_employee ORDER BY id DESC";  
           $result = mysqli_query($connect, $select_query);  
           $output .= '  
                <table class="table table-bordered">  
                     <tr>  
                          <th width="70%">Name</th>  
                          <th width="15%">Edit</th>  
                          <th width="15%">View</th> 
                          <th width="15%">Delete</th>
                     </tr>  
           ';  
           while($row = mysqli_fetch_array($result))  
           {  
                $output .= '  
                     <tr>  
                          <td>' . $row["name"] . '</td>  
                          <td><input type="button" name="edit" value="Edit" id="'.$row["id"] .'" class="btn btn-info btn-xs edit_data" /></td>  
                          <td><input type="button" name="view" value="view" id="' . $row["id"] . '" class="btn btn-info btn-xs view_data" /></td>
                        <td><input type="button" name="delete" value="delete" id="' . $row["id"] . '" class="btn btn-danger btn-xs delete_data" /></td>
                     </tr>  
                ';  
           }  
           $output .= '</table>'; 
    }
       echo $output;  
}  



 ?>
 