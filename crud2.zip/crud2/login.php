<?php
	session_start();
	$username = $_POST['username'];
	$password = $_POST['password'];
	
	$_SESSION['username']= $username;
	
	$conn = new mysqli("localhost","root","","juan");
	if($conn->connect_error)
	{	
		die("Can't connect to server");
	}
	
	$result = $conn->query("SELECT * FROM user WHERE username = '$username' and password = '$password'");
	
	if($result->num_rows>0){
		echo"
			<script>
				alert('Welcome to PEOPLE ARK SUB ADMIN PANEL!');
				window.location.href='index.php';
			</script>
		";
	}
	else{
		echo"
			<script>
				alert('Incorrect username or password! Try again.');
				window.location.href='login.html';
			</script>
		";
	}
	$row=$result->fetch_assoc();
	$_SESSION['id'] = $row['userID'];
?>